<?php

    // Capturar os dados do formulário
    $user_id = $_SESSION['user_id'] ?? 0;

    // Consultar a tabela 'utilizadores' para verificar se o nome existe
    $sql = "SELECT * FROM utilizadores WHERE id = :id LIMIT 1";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['id' => $user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user) {

    } else {
        // id de utilizador não encontrado
        $_SESSION['error'] = "Erro de segurança!";
        header("Location: index.php"); // Redireciona de volta para o formulário
        exit();
    }

?>