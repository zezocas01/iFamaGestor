<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!defined('NOME_EMPRESA')) {
    define('NOME_EMPRESA', 'iFama');
}


try {
    $pdo = new PDO('mysql:host=localhost;dbname=ifamagestor', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die('Erro ao conectar com o banco de dados: ' . $e->getMessage());
}