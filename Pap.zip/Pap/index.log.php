<?php
    include "config.php";

$loginNome = $_POST['loginNome'] ?? '';
    $loginPassword = $_POST['loginPassword'] ?? '';

    $sql = "SELECT * FROM utilizadores WHERE Nome = :nome LIMIT 1";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['nome' => $loginNome]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user) {
        if (password_verify($loginPassword, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['Nome'];
            header("Location: home.php");
            exit();
        } else {
            $_SESSION['error'] = "Senha incorreta!";
            header("Location: index.php");
            exit();
        }
    } else {
        $_SESSION['error'] = "Nome de utilizador não encontrado!";
        header("Location: index.php");
        exit();
    }

?>