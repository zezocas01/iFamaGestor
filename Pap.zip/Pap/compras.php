<?php
require 'config.php';

$op = isset($_GET['op']) ? $_GET['op'] : "";

if ($op == "new") {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Dados do Produto
        $Nome = $_POST['Nome'];
        $Modelo = $_POST['Modelo'];
        $PrecoCompra = $_POST['PrecoCompra'];
        $PrecoVenda = $_POST['PrecoVenda'];
        $StockAtual = $_POST['Quantidade']; // Stock = Quantidade comprada
        $Estado = $_POST['Estado'];
        
        // Dados da Compra
        $FornecedorID = $_POST['FornecedorID'];
        $Quantidade = $_POST['Quantidade'];
        $CustoTotal = $Quantidade * $PrecoCompra;

        try {
            $pdo->beginTransaction();

            // 1. Inserir o novo produto
            $sqlProduto = "INSERT INTO produtos (Nome, Modelo, PrecoCompra, PrecoVenda, StockAtual, Estado) 
                          VALUES (:Nome, :Modelo, :PrecoCompra, :PrecoVenda, :StockAtual, :Estado)";
            $stmtProduto = $pdo->prepare($sqlProduto);
            $stmtProduto->execute([
                ':Nome' => $Nome,
                ':Modelo' => $Modelo,
                ':PrecoCompra' => $PrecoCompra,
                ':PrecoVenda' => $PrecoVenda,
                ':StockAtual' => $StockAtual,
                ':Estado' => $Estado
            ]);
            
            // Obter o ID do novo produto
            $ProdutoID = $pdo->lastInsertId();

            // 2. Registrar a compra
            $sqlCompra = "INSERT INTO compras (FornecedorID, ProdutoID, Quantidade, CustoTotal) 
                         VALUES (:FornecedorID, :ProdutoID, :Quantidade, :CustoTotal)";
            $stmtCompra = $pdo->prepare($sqlCompra);
            $stmtCompra->execute([
                ':FornecedorID' => $FornecedorID,
                ':ProdutoID' => $ProdutoID,
                ':Quantidade' => $Quantidade,
                ':CustoTotal' => $CustoTotal
            ]);

            $pdo->commit();
            $_SESSION['mensagem'] = "<div class='alert alert-success'>Compra registrada com sucesso!</div>";
        } catch (Exception $e) {
            $pdo->rollBack();
            $_SESSION['mensagem'] = "<div class='alert alert-danger'>Erro: " . $e->getMessage() . "</div>";
        }
        
        /*header("Location: home.php?page=compras");
        exit();*/
    } else {
        include 'add_compra_form.php'; // Formulário de nova compra
    }
}
?>

<!-- Interface Compras -->
<div class="col-sm-6">
    <ol class="breadcrumb float-sm-end">
        <li class="breadcrumb-item"><a href="#">iFama</a></li>
        <li class="breadcrumb-item active">Compras</li>
    </ol>
</div>

<div class="app-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-12">
                <button class="btn btn-primary mb-3" onclick="openAddCompraForm()">Nova Compra</button>
                <div class="small-box text-bg-success">
                    <div class="card-body p-0">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Produto</th>
                                    <th>Fornecedor</th>
                                    <th>Quantidade</th>
                                    <th>Custo Total</th>
                                    <th>Data</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sql = "SELECT c.*, p.Nome AS ProdutoNome FROM compras c 
                                        INNER JOIN produtos p ON c.ProdutoID = p.ProdutoID 
                                        ORDER BY c.DataCompra DESC";
                                $stmt = $pdo->query($sql);
                                $compras = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                
                                foreach ($compras as $compra) {
                                    echo "<tr>";
                                    echo "<td>" . $compra['CompraID'] . "</td>";
                                    echo "<td>" . $compra['ProdutoNome'] . "</td>";
                                    echo "<td>" . $compra['FornecedorID'] . "</td>"; // Substitua por nome do fornecedor se existir
                                    echo "<td>" . $compra['Quantidade'] . "</td>";
                                    echo "<td>€" . number_format($compra['CustoTotal'], 2) . "</td>";
                                    echo "<td>" . date('d/m/Y H:i', strtotime($compra['DataCompra'])) . "</td>";
                                    echo "</tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Nova Compra -->
<div class="modal fade" id="addCompraModal" tabindex="-1" aria-labelledby="addCompraModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addCompraModalLabel">Nova Compra</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="home.php?page=compras&op=new" method="POST">
                    <!-- Dados do Produto -->
                    <div class="mb-3">
                        <label class="form-label">Nome do Produto</label>
                        <input type="text" class="form-control" name="Nome" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Capacidade</label>
                        <select class="form-select" name="Modelo" required>
                            <option value="64GB">64GB</option>
                            <option value="128GB">128GB</option>
                            <option value="256GB">256GB</option>
                            <option value="512GB">512GB</option>
                            <option value="1TB">1TB</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Preço de Compra (Unitário)</label>
                        <input type="number" class="form-control" name="PrecoCompra" step="0.01" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Preço de Venda (Unitário)</label>
                        <input type="number" class="form-control" name="PrecoVenda" step="0.01" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Quantidade</label>
                        <input type="number" class="form-control" name="Quantidade" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Estado</label>
                        <select class="form-select" name="Estado" required>
                            <option value="Satisfatório">Satisfatório</option>
                            <option value="Bom">Bom</option>
                            <option value="Muito Bom">Muito Bom</option>
                        </select>
                    </div>
                    
                    <!-- Dados da Compra -->
                    <div class="mb-3">
                        <label class="form-label">Fornecedor</label>
                        <select class="form-select" name="FornecedorID" required>
                            <!-- Popule com fornecedores do banco de dados -->
                            <option value="1">Fornecedor A</option>
                            <option value="2">Fornecedor B</option>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-success">Registrar Compra</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function openAddCompraForm() {
    const modal = new bootstrap.Modal(document.getElementById('addCompraModal'));
    modal.show();
}
</script>