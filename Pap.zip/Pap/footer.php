                <footer class="app-footer">
            <strong>
                Copyright &copy; <?=date('Y')?>&nbsp; <?=NOME_EMPRESA?>
            </strong>
            Todos os direitos reservados
        </footer>

        