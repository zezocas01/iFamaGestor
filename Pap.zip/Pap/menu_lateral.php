<aside class="app-sidebar bg-body-secondary shadow" data-bs-theme="dark">
    <div class="sidebar-brand">
        <a href="./home.php" class="brand-link">
            <img src="./assets/img/logo_Branco_sfundo.png" alt="Logo Branco" class="brand-image opacity-75 shadow">
            <span class="brand-text fw-light"> - Gestor</span>
        </a>
    </div>
    <div class="sidebar-wrapper">
        <nav class="mt-2">
            <ul class="nav sidebar-menu flex-column" role="menu" data-accordion="false">
                <li class="nav-item">
                    <a href="home.php?page=dashboard" class="nav-link <?php echo ($page == 'dashboard') ? 'active' : ''; ?>">
                        <i class="nav-icon bi bi-palette"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="home.php?page=vendas" class="nav-link <?php echo ($page == 'vendas') ? 'active' : ''; ?>">
                        <i class="nav-icon bi bi-cash"></i>
                        <p>Vendas</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="home.php?page=compras" class="nav-link <?php echo ($page == 'compras') ? 'active' : ''; ?>">
                        <i class="nav-icon bi bi-cart-fill"></i>
                        <p>Compras</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="home.php?page=produtos" class="nav-link <?php echo ($page == 'produtos') ? 'active' : ''; ?>">
                        <i class="nav-icon bi bi-box-seam"></i>
                        <p>Produtos</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="home.php?page=reparacoes" class="nav-link <?php echo ($page == 'reparacoes') ? 'active' : ''; ?>">
                        <i class="nav-icon bi bi-tools"></i>
                        <p>Reparações</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="home.php?page=clientes" class="nav-link <?php echo ($page == 'clientes') ? 'active' : ''; ?>">
                        <i class="nav-icon bi bi-people-fill"></i>
                        <p>Clientes</p>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</aside>