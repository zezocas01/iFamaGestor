<?php
require 'config.php';

$op = isset($_GET['op']) ? $_GET['op'] : "";

if ($op == "new") {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $ProdutoID = $_POST['ProdutoID'];
        $ClienteID = $_POST['ClienteID'];
        $Quantidade = $_POST['Quantidade'];

        try {
            $pdo->beginTransaction();

            // 1. Verificar stock primeiro
            $sqlCheckStock = "SELECT StockAtual FROM produtos WHERE ProdutoID = :ProdutoID";
            $stmtCheckStock = $pdo->prepare($sqlCheckStock);
            $stmtCheckStock->execute([':ProdutoID' => $ProdutoID]);
            $stock = $stmtCheckStock->fetch(PDO::FETCH_ASSOC);

            if ($stock['StockAtual'] < $Quantidade) {
                throw new Exception("Stock insuficiente!");
            }

            // 2. Registrar a venda (apenas ClienteID)
            $sqlVenda = "INSERT INTO vendas (ClienteID) VALUES (:ClienteID)";
            $stmtVenda = $pdo->prepare($sqlVenda);
            $stmtVenda->execute([':ClienteID' => $ClienteID]);
            $VendaID = $pdo->lastInsertId();

            // 3. Obter preço de venda do produto
            $sqlPreco = "SELECT PrecoVenda FROM produtos WHERE ProdutoID = :ProdutoID";
            $stmtPreco = $pdo->prepare($sqlPreco);
            $stmtPreco->execute([':ProdutoID' => $ProdutoID]);
            $preco = $stmtPreco->fetch(PDO::FETCH_ASSOC);
            $PrecoVenda = $preco['PrecoVenda'];

            // 4. Registrar os produtos na tabela Vendas_Produtos
            $sqlVendaProduto = "INSERT INTO Vendas_Produtos 
                               (VendaID, ProdutoID, Quantidade, PrecoUnitario) 
                               VALUES 
                               (:VendaID, :ProdutoID, :Quantidade, :PrecoVenda)";
            $stmtVendaProduto = $pdo->prepare($sqlVendaProduto);
            $stmtVendaProduto->execute([
                ':VendaID' => $VendaID,
                ':ProdutoID' => $ProdutoID,
                ':Quantidade' => $Quantidade,
                ':PrecoVenda' => $PrecoVenda
            ]);

            // 5. Atualizar o stock
            $sqlUpdateStock = "UPDATE produtos SET StockAtual = StockAtual - :Quantidade 
                              WHERE ProdutoID = :ProdutoID";
            $stmtUpdate = $pdo->prepare($sqlUpdateStock);
            $stmtUpdate->execute([
                ':Quantidade' => $Quantidade,
                ':ProdutoID' => $ProdutoID
            ]);

            $pdo->commit();
            $_SESSION['mensagem'] = "<div class='alert alert-success'>Venda registrada com sucesso!</div>";
        } catch (Exception $e) {
            $pdo->rollBack();
            $_SESSION['mensagem'] = "<div class='alert alert-danger'>Erro: " . $e->getMessage() . "</div>";
        }
        
        /*header("Location: home.php?page=vendas");
        exit();*/
    } else {
        include 'add_venda_form.php';
    }
}
?>

<div class="col-sm-6">
    <ol class="breadcrumb float-sm-end">
        <li class="breadcrumb-item"><a href="#">iFama</a></li>
        <li class="breadcrumb-item active">Vendas</li>
    </ol>
</div>

<div class="app-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-12">
                <button class="btn btn-primary mb-3" onclick="openAddVendaForm()">Nova Venda</button>
                <div class="small-box text-bg-success">
                    <div class="card-body p-0">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Cliente</th>
                                    <th>Produto</th>
                                    <th>Quantidade</th>
                                    <th>Total</th>
                                    <th>Data</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sql = "SELECT 
                                            v.VendaID,
                                            c.Nome AS ClienteNome,
                                            p.Nome AS ProdutoNome,
                                            vp.Quantidade,
                                            vp.PrecoUnitario AS PrecoVenda,
                                            v.DataVenda
                                        FROM vendas v
                                        INNER JOIN Vendas_Produtos vp ON v.VendaID = vp.VendaID
                                        INNER JOIN produtos p ON vp.ProdutoID = p.ProdutoID
                                        INNER JOIN clientes c ON v.ClienteID = c.ClienteID
                                        ORDER BY v.DataVenda DESC";
                                $stmt = $pdo->query($sql);
                                $vendas = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                
                                foreach ($vendas as $venda) {
                                    $total = $venda['Quantidade'] * $venda['PrecoVenda'];
                                    echo "<tr>";
                                    echo "<td>" . $venda['VendaID'] . "</td>";
                                    echo "<td>" . $venda['ClienteNome'] . "</td>";
                                    echo "<td>" . $venda['ProdutoNome'] . "</td>";
                                    echo "<td>" . $venda['Quantidade'] . "</td>";
                                    echo "<td>€" . number_format($total, 2) . "</td>";
                                    echo "<td>" . date('d/m/Y H:i', strtotime($venda['DataVenda'])) . "</td>";
                                    echo "</tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="addVendaModal" tabindex="-1" aria-labelledby="addVendaModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addVendaModalLabel">Nova Venda</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="home.php?page=vendas&op=new" method="POST">
                    <div class="mb-3">
                        <label class="form-label">Cliente</label>
                        <select class="form-select" name="ClienteID" required>
                            <?php
                            $sqlClientes = "SELECT ClienteID, Nome FROM clientes";
                            $stmtClientes = $pdo->query($sqlClientes);
                            $clientes = $stmtClientes->fetchAll(PDO::FETCH_ASSOC);
                            foreach ($clientes as $cliente) {
                                echo "<option value='{$cliente['ClienteID']}'>{$cliente['Nome']}</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Produto</label>
                        <select class="form-select" name="ProdutoID" required>
                            <?php
                            $sqlProdutos = "SELECT ProdutoID, Nome, StockAtual FROM produtos WHERE StockAtual > 0";
                            $stmtProdutos = $pdo->query($sqlProdutos);
                            $produtos = $stmtProdutos->fetchAll(PDO::FETCH_ASSOC);
                            foreach ($produtos as $produto) {
                                echo "<option value='{$produto['ProdutoID']}'>{$produto['Nome']} (Stock: {$produto['StockAtual']})</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Quantidade</label>
                        <input type="number" class="form-control" name="Quantidade" required>
                    </div>
                    <button type="submit" class="btn btn-success">Registrar Venda</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function openAddVendaForm() {
    const modal = new bootstrap.Modal(document.getElementById('addVendaModal'));
    modal.show();
}
</script>