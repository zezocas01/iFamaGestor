<?php
require 'config.php';

try {
    $sql = file_get_contents('schema.sql');


    $pdo->exec($sql);
    echo "Banco de dados configurado com sucesso!";
} catch (PDOException $e) {
    die("Erro ao configurar o banco de dados: " . $e->getMessage());
}
