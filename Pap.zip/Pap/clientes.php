<?php
//require 'config.php';

$estouEm = 1;

$op = isset($_GET['op']) ? $_GET['op'] : "";

if ($op == "new") {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $Nome = $_POST['Nome'];
        $Nif = $_POST['Nif'];
        $Telefone = $_POST['Telefone'];
        $Email = $_POST['Email'];
        $Morada = $_POST['Morada'];

        $sql = "INSERT INTO clientes (Nome, Nif, Telefone, Email, Morada, DataCriacao) 
                VALUES (:Nome, :Nif, :Telefone, :Email, :Morada, CURRENT_TIMESTAMP)";
        
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':Nome', $Nome);
        $stmt->bindParam(':Nif', $Nif);
        $stmt->bindParam(':Telefone', $Telefone);
        $stmt->bindParam(':Email', $Email);
        $stmt->bindParam(':Morada', $Morada);

        if ($stmt->execute()) {
            $_SESSION['mensagem'] = "Cliente adicionado com sucesso!";
        } else {
            $_SESSION['mensagem'] = "Erro ao adicionar o cliente.";
        }
        /*header("Location: /home.php?page=clientes");
        exit();*/

    } else {
        include 'add_client_form.php';
    }
}
elseif ($op == "edit") {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $ClienteID = $_POST['ClienteID'];
        $Nome = $_POST['Nome'];
        $Nif = $_POST['Nif'];
        $Telefone = $_POST['Telefone'];
        $Email = $_POST['Email'];
        $Morada = $_POST['Morada'];

        $sql = "UPDATE clientes SET 
                Nome = :Nome,
                Nif = :Nif,
                Telefone = :Telefone,
                Email = :Email,
                Morada = :Morada
                WHERE ClienteID = :ClienteID";

        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':Nome', $Nome);
        $stmt->bindParam(':Nif', $Nif);
        $stmt->bindParam(':Telefone', $Telefone);
        $stmt->bindParam(':Email', $Email);
        $stmt->bindParam(':Morada', $Morada);
        $stmt->bindParam(':ClienteID', $ClienteID);

        if ($stmt->execute()) {
            $_SESSION['mensagem'] = "<div class='alert alert-success'>Cliente atualizado com sucesso!</div>";
        } else {
            $_SESSION['mensagem'] = "<div class='alert alert-danger'>Erro ao atualizar o cliente.</div>";
        }
        /*header("Location: /home.php?page=clientes");
        exit();*/

    } 
    else {
        $ClienteID = $_GET['ClienteID'];
        $sql = "SELECT * FROM clientes WHERE ClienteID = :ClienteID";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':ClienteID', $ClienteID);
        $stmt->execute();
        $cliente = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($cliente) {
            include 'edit_client_form.php';
        } else {
            echo "Cliente não encontrado.";
        }
    }
} 
elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['op']) && $_POST['op'] == "delete") {
    //print_r($_POST);
    try {
        $ClienteID = $_POST['ClienteID'];
        
        $sql = "DELETE FROM clientes WHERE ClienteID = :ClienteID";
        //echo $sql . $ClienteID;
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':ClienteID', $ClienteID);
        
        if ($stmt->execute()) {
            $_SESSION['mensagem'] = "Cliente deletado com sucesso!";
        } else {
            $_SESSION['mensagem'] = "Erro ao deletar o cliente.";
        }
    } catch (PDOException $e) {
        $_SESSION['mensagem'] = "Erro: " . $e->getMessage();
    }
    //header("Location: /home.php?page=clientes");
    //exit();
}
?>



<!-- Interface -->
<div class="col-sm-6">
    <ol class="breadcrumb float-sm-end">
        <li class="breadcrumb-item"><a href="#">iFama</a></li>
        <li class="breadcrumb-item active" aria-current="page">
                                    Clientes
                                </li>
    </ol>
</div>

<div class="app-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-12">
                <button class="btn btn-primary mb-3" onclick="openAddClientForm()">Adicionar Cliente</button>
                <div class="small-box text-bg-success">
                    <div class="card-body p-0">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Nome</th>
                                    <th>NIF</th>
                                    <th>Telefone</th>
                                    <th>Email</th>
                                    <th>Morada</th>
                                    <th>Data Registo</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sql = "SELECT * FROM clientes ORDER BY ClienteID DESC";
                                $stmt = $pdo->query($sql);
                                $clientes = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                
                                foreach ($clientes as $cliente) {
                                    echo "<tr>";
                                    echo "<td>" . $cliente['ClienteID'] . "</td>";
                                    echo "<td>" . $cliente['Nome'] . "</td>";
                                    echo "<td>" . $cliente['Nif'] . "</td>";
                                    echo "<td>" . $cliente['Telefone'] . "</td>";
                                    echo "<td>" . $cliente['Email'] . "</td>";
                                    echo "<td>" . $cliente['Morada'] . "</td>";
                                    echo "<td>" . date('d/m/Y H:i', strtotime($cliente['DataCriacao'])) . "</td>";
                                    echo '<td>
                                            <button class="btn btn-warning btn-sm" onclick="openEditForm(' . $cliente['ClienteID'] . ')">Editar</button>
                                            <button class="btn btn-danger btn-sm" onclick="deleteClient(' . $cliente['ClienteID'] . ')">Apagar</button>
                                          </td>';
                                    echo "</tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Adicionar Cliente -->
<div class="modal fade" id="addClientModal" tabindex="-1" aria-labelledby="addClientModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addClientModalLabel">Novo Cliente</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="home.php?page=clientes&op=new" method="POST">
                    <div class="mb-3">
                        <label class="form-label">Nome Completo</label>
                        <input type="text" class="form-control" name="Nome" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">NIF</label>
                        <input type="text" class="form-control" name="Nif" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Telefone</label>
                        <input type="tel" class="form-control" name="Telefone" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" class="form-control" name="Email">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Morada</label>
                        <textarea class="form-control" name="Morada" rows="3"></textarea>
                    </div>
                    <button type="submit" class="btn btn-success">Registar Cliente</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal Editar Cliente -->
<div class="modal fade" id="editClientModal" tabindex="-1" aria-labelledby="editClientModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editClientModalLabel">Editar Cliente</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="editClientForm" action="home.php?page=clientes&op=edit" method="POST">
                    <input type="hidden" name="ClienteID" value="<?php echo $cliente['ClienteID']; ?>">
                    
                    <div class="mb-3">
                        <label class="form-label">Nome Completo</label>
                        <input type="text" class="form-control" name="Nome" 
                            value="<?php echo $cliente['Nome']; ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">NIF</label>
                        <input type="text" class="form-control" name="Nif" 
                            value="<?php echo $cliente['Nif']; ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Telefone</label>
                        <input type="tel" class="form-control" name="Telefone" 
                            value="<?php echo $cliente['Telefone']; ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" class="form-control" name="Email" 
                            value="<?php echo $cliente['Email']; ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Morada</label>
                        <textarea class="form-control" name="Morada" rows="3"><?php echo $cliente['Morada']; ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Data de Registo</label>
                        <input type="text" class="form-control" 
                            value="<?php echo date('d/m/Y H:i', strtotime($cliente['DataCriacao'])); ?>" readonly>
                    </div>
                    <button type="submit" class="btn btn-success">Salvar Alterações</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function openAddClientForm() {
    const modal = new bootstrap.Modal(document.getElementById('addClientModal'));
    modal.show();
}

function openEditForm(id) {
    window.location.href = `home.php?page=clientes&op=edit&ClienteID=${id}`;
}

function deleteClient(id) {
    if (confirm('Tem certeza que deseja apagar este cliente?')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = 'home.php?page=clientes';
        
        const opInput = document.createElement('input');
        opInput.type = 'hidden';
        opInput.name = 'op';
        opInput.value = 'delete';
        form.appendChild(opInput);

        const idInput = document.createElement('input');
        idInput.type = 'hidden';
        idInput.name = 'ClienteID';
        idInput.value = id;
        form.appendChild(idInput);

        document.body.appendChild(form);
        form.submit();
    }
}

// Mostra o modal de edição automaticamente quando a página carrega para edição
<?php if($op == 'edit'): ?>
window.onload = function() {
    const modal = new bootstrap.Modal(document.getElementById('editClientModal'));
    modal.show();
};
<?php endif; ?>
</script>