<?php
    require 'config.php';

    $op = isset($_GET['op']) ? $_GET['op'] : "";

    $clientes = $pdo->query("SELECT * FROM clientes")->fetchAll();
    $produtos = $pdo->query("SELECT * FROM produtos")->fetchAll();    

    if ($op == "new") {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $ClienteID = $_POST['ClienteID'];
            $ProdutoID = $_POST['ProdutoID'];
            $TipoReparacao = $_POST['TipoReparacao'];
            $Custo = $_POST['Custo'];
            $DataReparacao = $_POST['DataReparacao'];
    
            $sql = "INSERT INTO reparacoes (ClienteID, ProdutoID, TipoReparacao, Custo, DataReparacao) 
                    VALUES (:ClienteID, :ProdutoID, :TipoReparacao, :Custo, :DataReparacao)";
            
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':ClienteID', $ClienteID);
            $stmt->bindParam(':ProdutoID', $ProdutoID);
            $stmt->bindParam(':TipoReparacao', $TipoReparacao);
            $stmt->bindParam(':Custo', $Custo);
            $stmt->bindParam(':DataReparacao', $DataReparacao);
    
            if ($stmt->execute()) {
                $_SESSION['mensagem'] = "Reparação adicionada com sucesso!";
            } else {
                $_SESSION['mensagem'] = "Erro ao adicionar a reparação.";
            }
            /*header("Location: /home.php?page=reparacoes");
            exit();*/

        } else {
            // Obter clientes e produtos para dropdowns
            $clientes = $pdo->query("SELECT * FROM clientes")->fetchAll();
            $produtos = $pdo->query("SELECT * FROM produtos")->fetchAll();
            include 'add_repair_form.php';
        }
    }
    elseif ($op == "edit") {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $ReparacaoID = $_POST['ReparacaoID'];
            $ClienteID = $_POST['ClienteID'];
            $ProdutoID = $_POST['ProdutoID'];
            $TipoReparacao = $_POST['TipoReparacao'];
            $Custo = $_POST['Custo'];
            $DataReparacao = $_POST['DataReparacao'];

            $sql = "UPDATE reparacoes SET 
                    ClienteID = :ClienteID,
                    ProdutoID = :ProdutoID,
                    TipoReparacao = :TipoReparacao,
                    Custo = :Custo,
                    DataReparacao = :DataReparacao
                    WHERE ReparacaoID = :ReparacaoID";

            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':ClienteID', $ClienteID);
            $stmt->bindParam(':ProdutoID', $ProdutoID);
            $stmt->bindParam(':TipoReparacao', $TipoReparacao);
            $stmt->bindParam(':Custo', $Custo);
            $stmt->bindParam(':DataReparacao', $DataReparacao);
            $stmt->bindParam(':ReparacaoID', $ReparacaoID);

            if ($stmt->execute()) {
                $_SESSION['mensagem'] = "<div class='alert alert-success'>Reparação atualizada com sucesso!</div>";
            } else {
                $_SESSION['mensagem'] = "<div class='alert alert-danger'>Erro ao atualizar a reparação.</div>";
            }
            /*header("Location: /home.php?page=reparacoes");
            exit();*/

        } 
        else {
            $ReparacaoID = $_GET['ReparacaoID'];
            $sql = "SELECT * FROM reparacoes WHERE ReparacaoID = :ReparacaoID";
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':ReparacaoID', $ReparacaoID);
            $stmt->execute();
            $reparacao = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($reparacao) {

                include 'edit_repair_form.php';
            } else {
                echo "Reparação não encontrada.";
            }
        }
    } 

    elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['op']) && $_POST['op'] == "delete") {
        try {
            $ReparacaoID = $_POST['ReparacaoID'];
            
            $sql = "DELETE FROM reparacoes WHERE ReparacaoID = :ReparacaoID";
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':ReparacaoID', $ReparacaoID);
            
            if ($stmt->execute()) {
                $_SESSION['mensagem'] = "Reparação deletada com sucesso!";
            } else {
                $_SESSION['mensagem'] = "Erro ao deletar a reparação.";
            }
        } catch (PDOException $e) {
            $_SESSION['mensagem'] = "Erro: " . $e->getMessage();
        }
        /*header("Location: /home.php?page=reparacoes");
        exit();*/
    }
?>

<div class="col-sm-6">
    <ol class="breadcrumb float-sm-end">
        <li class="breadcrumb-item"><a href="#">iFama</a></li>
        <li class="breadcrumb-item active" aria-current="page">Reparações</li>
    </ol>
</div>

<div class="app-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-12">
                <button class="btn btn-primary mb-3" onclick="openAddRepairForm()">Adicionar</button>
                <div class="small-box text-bg-success">
                    <div class="card-body p-0">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Cliente</th>
                                    <th>Produto</th>
                                    <th>Tipo Reparação</th>
                                    <th>Custo</th>
                                    <th>Data</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sql = "SELECT r.*, c.Nome AS NomeCliente, p.Nome AS NomeProduto 
                                        FROM reparacoes r
                                        LEFT JOIN clientes c ON r.ClienteID = c.ClienteID
                                        LEFT JOIN produtos p ON r.ProdutoID = p.ProdutoID
                                        ORDER BY r.ReparacaoID DESC";
                                $stmt = $pdo->query($sql);
                                $reparacoes = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                
                                foreach ($reparacoes as $reparacao) {
                                    echo "<tr>";
                                    echo "<td>" . $reparacao['ReparacaoID'] . "</td>";
                                    echo "<td>" . $reparacao['NomeCliente'] . "</td>";
                                    echo "<td>" . $reparacao['NomeProduto'] . "</td>";
                                    echo "<td>" . $reparacao['TipoReparacao'] . "</td>";
                                    echo "<td>" . number_format($reparacao['Custo'], 2) . " €</td>";
                                    echo "<td>" . date('d/m/Y', strtotime($reparacao['DataReparacao'])) . "</td>";
                                    echo '<td>
                                            <button class="btn btn-warning btn-sm" onclick="openEditForm(' . $reparacao['ReparacaoID'] . ')">Editar</button>
                                            <button class="btn btn-danger btn-sm" onclick="deleteRepair(' . $reparacao['ReparacaoID'] . ')">Apagar</button>
                                          </td>';
                                    echo "</tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Adicionar Reparação -->
<div class="modal fade" id="addRepairModal" tabindex="-1" aria-labelledby="addRepairModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addRepairModalLabel">Nova Reparação</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="home.php?page=reparacoes&op=new" method="POST">
                    <div class="mb-3">
                        <label class="form-label">Cliente</label>
                        <select class="form-select" name="ClienteID" required>
                            <?php foreach ($clientes as $cliente): ?>
                                <option value="<?= $cliente['ClienteID'] ?>"><?= $cliente['Nome'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Produto</label>
                        <select class="form-select" name="ProdutoID" required>
                            <?php foreach ($produtos as $produto): ?>
                                <option value="<?= $produto['ProdutoID'] ?>"><?= $produto['Nome'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Tipo de Reparação</label>
                        <input type="text" class="form-control" name="TipoReparacao" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Custo</label>
                        <input type="number" class="form-control" name="Custo" step="0.01" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Data</label>
                        <input type="date" class="form-control" name="DataReparacao" required>
                    </div>
                    <button type="submit" class="btn btn-success">Salvar</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function openAddRepairForm() {
    const modal = new bootstrap.Modal(document.getElementById('addRepairModal'));
    modal.show();
}

function openEditForm(id) {
    window.location.href = `home.php?page=reparacoes&op=edit&ReparacaoID=${id}`;
}

function deleteRepair(id) {
    if (confirm('Tem certeza que deseja apagar esta reparação?')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = 'home.php?page=reparacoes';
        
        const opInput = document.createElement('input');
        opInput.type = 'hidden';
        opInput.name = 'op';
        opInput.value = 'delete';
        form.appendChild(opInput);

        const idInput = document.createElement('input');
        idInput.type = 'hidden';
        idInput.name = 'ReparacaoID';
        idInput.value = id;
        form.appendChild(idInput);

        document.body.appendChild(form);
        form.submit();
    }
}
</script>