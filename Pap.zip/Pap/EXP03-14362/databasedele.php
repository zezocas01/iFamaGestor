<?php 
include "conn.php"; 

if (isset($_GET['id'])) {

    $user_id = $_GET['id'];

    $sql = "DELETE FROM utilizadores WHERE user_id = '$user_id'";

    $result = $conn->query($sql);

     if ($result == TRUE) {

        echo "Record deleted successfully.";
        header("location: index.php");

    }else{

        echo "Error:" . $sql . "<br>" . $conn->error;

    }

} 

?>