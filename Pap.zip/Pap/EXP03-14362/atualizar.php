<?php

include "conn.php";

if (isset($_POST['id'])) {

    $user_id = $_POST['id'];
    $nome = $_POST['nome'];
    $apelido = $_POST['apelido'];
    $morada = $_POST['morada'];

    $sql = "UPDATE utilizadores SET user_id='$user_id',nome='$nome',apelido='$apelido',morada=' $morada' WHERE user_id = '$user_id'";

    $result = $conn->query($sql);

     if ($result == TRUE) {

        echo "Record deleted successfully.";
        header("location: index.php");

    }else{

        echo "Error:" . $sql . "<br>" . $conn->error;

    }

} 





?>