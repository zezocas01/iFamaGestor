<?php
	require 'conn.php';
	
	if(ISSET($_POST['procurar'])){
?>
 <head>
    <script src="https://kit.fontawesome.com/yourcode.js" crossorigin="anonymous"></script>
 </head>
	<table class="table table-bordered">
		<thead class="alert-info">
			<tr>
				<th>Nome</th>
				<th>Apelido</th>
				<th>Morada</th>
				<th>Editar</th>
				<th>Apagar</th>
			</tr>
		</thead>
		<tbody>
			<?php
				$keyword = $_POST['keyword'];
				$query = $conn->prepare("SELECT * FROM `utilizadores` WHERE `nome` LIKE '%$keyword%' or `apelido` LIKE '%$keyword%' or `morada` LIKE '%$keyword%'");
				$query->execute();
				while($row = $query->fetch()){
			?>
			<tr>
			
				<td><?php echo $row['nome']?></td>
				<td><?php echo $row['apelido']?></td>
				<td><?php echo $row['morada']?></td>
				<td><a href="dbedit.php?id=<?php echo $row['user_id']; ?>"><i class='fas fa-edit' style='color: #0047AB;'></i></a></td>
				<td><a href="databasedele.php?id=<?php echo $row['user_id']; ?>"><i class='fas fa-trash' style='color: #db0000;'></i></a></td>
			</tr>
 
 
			<?php
				}
			?>
		</tbody>
	</table>
<?php		
	}else if(ISSET($_POST['mostrartodos'])){
	
?>
 <head>
    <script src="https://kit.fontawesome.com/yourcode.js" crossorigin="anonymous"></script>
 </head>
	<table class="table table-bordered">
		<thead class="alert-info">
			<tr>
				<th>Nome</th>
				<th>Apelido</th>
				<th>Morada</th>
				<th>Editar</th>
				<th>Apagar</th>
			</tr>
		</thead>
		<tbody>
			<?php
				$query = $conn->prepare("SELECT * FROM `utilizadores`");
				$query->execute();
				while($row = $query->fetch()){
			?>
			<tr>	
				<td><?php echo $row['nome']?></td>
				<td><?php echo $row['apelido']?></td>
				<td><?php echo $row['morada']?></td>
				<td><a href="dbedit.php?id=<?php echo $row['user_id']; ?>"><i class='fas fa-edit' style='color: #0047AB;'></i></a></td>
				<td><a href="databasedele.php?id=<?php echo $row['user_id']; ?>"><i class='fas fa-trash' style='color: #db0000;'></i></a></td>
			</tr>
 
 
			<?php
				}
			?>
		</tbody>
	</table>
<?php
	}else{
?>
	<table class="table table-bordered">
		<thead class="alert-info">
			<tr>
				<th>Nome</th>
				<th>Apelido</th>
				<th>Morada</th>
				<th>Editar</th>
				<th>Apagar</th>
			</tr>
		</thead>
		<tbody>
			<?php
				$query = $conn->prepare("SELECT * FROM `utilizadores`");
				$query->execute();
				while($row = $query->fetch()){
			?>
			 
			<tr>

				<td><?php echo $row['nome']?></td>

				<td><?php echo $row['apelido']?></td>
				<td><?php echo $row['morada']?></td>
				<td><a href="dbedit.php?id=<?php echo $row['user_id']; ?>"><i class='fas fa-edit' style='color: #0047AB;'></i></a></td>
				<td><a href="databasedele.php?id=<?php echo $row['user_id']; ?>"><i class='fas fa-trash' style='color: #db0000;' > </i></a></td>
				
                
			</tr>
 
 
			<?php
				}
			?>
		</tbody>
        
	</table>
<?php
	}
?>
