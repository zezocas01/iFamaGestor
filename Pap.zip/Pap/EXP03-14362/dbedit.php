<?php
include "conn.php"; 


if (isset($_GET['id'])) {

    $user_id = $_GET['id'];

    $query = $conn->prepare("SELECT * FROM `utilizadores` WHERE user_id = '$user_id'");
    $query->execute();
    while($row = $query->fetch()){
        $id = $row['user_id'];
         $nome = $row['nome'];
         $apelido =  $row['apelido'];
         $morada =  $row['morada'];

    }
}


?>



<!DOCTYPE html>
<html lang="pt">
	<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
		<meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1"/>
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">

	</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
            <h3 class="text-primary">Atualizar</h3>
            
                <hr style="border-top:1px dotted #ccc;" />
                <form method="POST" action="atualizar.php">
                <input type="hidden" value ="<?php echo $id; ?>" name="id" class="form-control" required="required"/>
                    <div class="form-group">
                        <label>Nome</label>
                        <input type="text" value ="<?php echo $nome; ?>" name="nome" class="form-control" required="required"/>
                    </div>
                    <div class="form-group">
                        <label>Apelido</label>
                        <input type="text" value ="<?php echo $apelido; ?>" name="apelido" class="form-control" required="required" />
                    </div>
                    <div class="form-group">
                        <label>Morada</label>
                        <input type="text" value ="<?php echo $morada; ?>" name="morada" class="form-control" required="required"/>
                    </div>
                    <br />
                    <button name="guardar" class="btn btn-primary">Guardar</button>
                </form>
                
            </div>
		    <div class="col-md-6">
            
		    </div>
        </div>
    </div>

</body>
</html>
