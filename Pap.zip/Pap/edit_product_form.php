<div class="modal fade" id="editProductModal" tabindex="-1" aria-labelledby="editProductModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editProductModalLabel">Editar Produto</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="editProductForm" action="home.php?page=produtos&op=edit" method="POST">
                    <input type="hidden" name="ProdutoID" value="<?php echo $produto['ProdutoID']; ?>">
                    <div class="mb-3">
                        <label for="Nome" class="form-label">Nome</label>
                        <input type="text" class="form-control" name="Nome" value="<?php echo $produto['Nome']; ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="Modelo" class="form-label">Capacidade</label>
                        <select class="form-select" name="Modelo" required>
                            <option value="64GB" <?php echo ($produto['Modelo'] == '64GB') ? 'selected' : ''; ?>>64GB</option>
                            <option value="128GB" <?php echo ($produto['Modelo'] == '128GB') ? 'selected' : ''; ?>>128GB</option>
                            <option value="256GB" <?php echo ($produto['Modelo'] == '256GB') ? 'selected' : ''; ?>>256GB</option>
                            <option value="512GB" <?php echo ($produto['Modelo'] == '512GB') ? 'selected' : ''; ?>>512GB</option>
                            <option value="1TB" <?php echo ($produto['Modelo'] == '1TB') ? 'selected' : ''; ?>>1TB</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="PrecoCompra" class="form-label">Preço de Compra</label>
                        <input type="number" class="form-control" name="PrecoCompra" value="<?php echo $produto['PrecoCompra']; ?>" step="0.01" required>
                    </div>
                    <div class="mb-3">
                        <label for="PrecoVenda" class="form-label">Preço de Venda</label>
                        <input type="number" class="form-control" name="PrecoVenda" value="<?php echo $produto['PrecoVenda']; ?>" step="0.01" required>
                    </div>
                    <div class="mb-3">
                        <label for="StockAtual" class="form-label">Stock Atual</label>
                        <input type="number" class="form-control" name="StockAtual" value="<?php echo $produto['StockAtual']; ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="Estado" class="form-label">Estado</label>
                        <select class="form-select" name="Estado" required>
                            <option value="Satisfatório" <?php echo ($produto['Estado'] == 'Satisfatório') ? 'selected' : ''; ?>>Satisfatório</option>
                            <option value="Bom" <?php echo ($produto['Estado'] == 'Bom') ? 'selected' : ''; ?>>Bom</option>
                            <option value="Muito Bom" <?php echo ($produto['Estado'] == 'Muito Bom') ? 'selected' : ''; ?>>Muito Bom</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-success">Salvar Alterações</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>

    window.onload = function() {
        const modal = new bootstrap.Modal(document.getElementById('editProductModal'));
        modal.show();
    };
</script>