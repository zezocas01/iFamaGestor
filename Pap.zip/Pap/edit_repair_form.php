<div class="modal fade" id="editRepairModal" tabindex="-1" aria-labelledby="editRepairModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editRepairModalLabel">Editar Reparação</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="editRepairForm" action="home.php?page=reparacoes&op=edit" method="POST">
                    <input type="hidden" name="ReparacaoID" value="<?php echo $reparacao['ReparacaoID']; ?>">
                    
                    <div class="mb-3">
                        <label class="form-label">Cliente</label>
                        <select class="form-select" name="ClienteID" required>
                            <?php foreach ($clientes as $cliente): ?>
                                <option value="<?= $cliente['ClienteID'] ?>" 
                                    <?= ($cliente['ClienteID'] == $reparacao['ClienteID']) ? 'selected' : '' ?>>
                                    <?= $cliente['Nome'] ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Produto</label>
                        <select class="form-select" name="ProdutoID" required>
                            <?php foreach ($produtos as $produto): ?>
                                <option value="<?= $produto['ProdutoID'] ?>" 
                                    <?= ($produto['ProdutoID'] == $reparacao['ProdutoID']) ? 'selected' : '' ?>>
                                    <?= $produto['Nome'] ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Tipo de Reparação</label>
                        <input type="text" class="form-control" name="TipoReparacao" 
                            value="<?php echo $reparacao['TipoReparacao']; ?>" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Custo</label>
                        <input type="number" class="form-control" name="Custo" 
                            value="<?php echo $reparacao['Custo']; ?>" step="0.01" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Data</label>
                        <input type="date" class="form-control" name="DataReparacao" 
                            value="<?php echo date('Y-m-d', strtotime($reparacao['DataReparacao'])); ?>" required>
                    </div>

                    <button type="submit" class="btn btn-success">Salvar Alterações</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    window.onload = function() {
        const modal = new bootstrap.Modal(document.getElementById('editRepairModal'));
        modal.show();
    };
</script>