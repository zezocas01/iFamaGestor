<?php
    require 'config.php';

    $op = isset($_GET['op']) ? $_GET['op'] : "";

    if ($op == "new") {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $Nome = $_POST['Nome'];
            $Modelo = $_POST['Modelo'];
            $PrecoCompra = $_POST['PrecoCompra'];
            $PrecoVenda = $_POST['PrecoVenda'];
            $StockAtual = $_POST['StockAtual'];
            $Estado = $_POST['Estado'];
    
            $sql = "INSERT INTO produtos (Nome, Modelo, PrecoCompra, PrecoVenda, StockAtual, Estado) 
                    VALUES (:Nome, :Modelo, :PrecoCompra, :PrecoVenda, :StockAtual, :Estado)";
            
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':Nome', $Nome);
            $stmt->bindParam(':Modelo', $Modelo);
            $stmt->bindParam(':PrecoCompra', $PrecoCompra);
            $stmt->bindParam(':PrecoVenda', $PrecoVenda);
            $stmt->bindParam(':StockAtual', $StockAtual);
            $stmt->bindParam(':Estado', $Estado);
    
            if ($stmt->execute()) {
                $_SESSION['mensagem'] = "Produto adicionado com sucesso!";
            } else {
                $_SESSION['mensagem'] = "Erro ao adicionar o produto.";
            }
            /*header("Location: /home.php?page=produtos");
            exit();*/

        } else {
            include 'add_product_form.php'; // Certifique-se de que este arquivo existe ou use o modal existente
        }
    }
    elseif ($op == "edit") {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $ProdutoID = $_POST['ProdutoID'];
            $Nome = $_POST['Nome'];
            $Modelo = $_POST['Modelo'];
            $PrecoCompra = $_POST['PrecoCompra'];
            $PrecoVenda = $_POST['PrecoVenda'];
            $StockAtual = $_POST['StockAtual'];
            $Estado = $_POST['Estado'];

            $sql = "UPDATE produtos SET Nome = :Nome, Modelo = :Modelo, PrecoCompra = :PrecoCompra, PrecoVenda = :PrecoVenda, StockAtual = :StockAtual, Estado = :Estado
                    WHERE ProdutoID = :ProdutoID";

            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':Nome', $Nome);
            $stmt->bindParam(':Modelo', $Modelo);
            $stmt->bindParam(':PrecoCompra', $PrecoCompra);
            $stmt->bindParam(':PrecoVenda', $PrecoVenda);
            $stmt->bindParam(':StockAtual', $StockAtual);
            $stmt->bindParam(':Estado', $Estado);
            $stmt->bindParam(':ProdutoID', $ProdutoID);

            if ($stmt->execute()) {
                $_SESSION['mensagem'] = "<div class='alert alert-success'>Produto atualizado com sucesso!</div>";
            } else {
                $_SESSION['mensagem'] = "<div class='alert alert-danger'>Erro ao atualizar o produto.</div>";
            }
            /*header("Location: /home.php?page=produtos");
            exit();*/

        } 
        else {
            $ProdutoID = $_GET['ProdutoID'];
            $sql = "SELECT * FROM produtos WHERE ProdutoID = :ProdutoID";
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':ProdutoID', $ProdutoID);
            $stmt->execute();
            $produto = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($produto) {
                include 'edit_product_form.php';
            } else {
                echo "Produto não encontrado.";
            }
        }
    } 

    /*if (isset($_SESSION['mensagem'])) {
        echo '<div class="alert alert-info">' . $_SESSION['mensagem'] . '</div>';
        unset($_SESSION['mensagem']); 

    }*/
     elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['op']) && $_POST['op'] == "delete") {
        try {
            $ProdutoID = $_POST['ProdutoID'];
            
            $sql = "DELETE FROM produtos WHERE ProdutoID = :ProdutoID";
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':ProdutoID', $ProdutoID);
            
            if ($stmt->execute()) {
                $_SESSION['mensagem'] = "Produto deletado com sucesso!";
            } else {
                $_SESSION['mensagem'] = "Erro ao deletar o produto.";
            }
        } catch (PDOException $e) {
            $_SESSION['mensagem'] = "Erro: " . $e->getMessage();
        }
        /*header("Location: /home.php?page=produtos");
        exit();*/
    }
?>


<div class="col-sm-6">
    <ol class="breadcrumb float-sm-end">
        <li class="breadcrumb-item"><a href="#">iFama</a></li>
        <li class="breadcrumb-item active" aria-current="page">Produtos</li>
    </ol>
</div>

<div class="app-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-12">
                <button class="btn btn-primary mb-3" onclick="openAddProductForm()">Adicionar</button>
                <div class="small-box text-bg-success">
                    <div class="card-body p-0">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th style="width: 10px">ID</th>
                                    <th>Nome</th>
                                    <th>Capacidade</th>
                                    <th>Preço de Compra</th>
                                    <th>Preço de Venda</th>
                                    <th>Stock Atual</th>
                                    <th>Estado</th>
                                    <th style="width: 40px">Ações</th>
                                </tr>
                            </thead>
                            <tbody id="productTableBody">
                                <?php
                                $sql = "SELECT * FROM produtos ORDER BY ProdutoID DESC";
                                $stmt = $pdo->query($sql);
                                $produtos = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                foreach ($produtos as $produto) {
                                    echo "<tr>";
                                    echo "<td>" . $produto['ProdutoID'] . "</td>";
                                    echo "<td>" . $produto['Nome'] . "</td>";
                                    echo "<td>" . $produto['Modelo'] . "</td>";
                                    echo "<td>" . $produto['PrecoCompra'] . "</td>";
                                    echo "<td>" . $produto['PrecoVenda'] . "</td>";
                                    echo "<td>" . $produto['StockAtual'] . "</td>";
                                    echo "<td>" . $produto['Estado'] . "</td>";
                                    echo '<td>
                                        <div class="d-flex gap-1">
                                        <button class="btn btn-warning btn-sm" onclick="openEditForm(' . $produto['ProdutoID'] . ')">Editar</button>
                                        <button class="btn btn-danger btn-sm" onclick="deleteProduct(' . $produto['ProdutoID'] . ')">Apagar</button>
                                        </div>
                                    </td>';
                                    echo "</tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="addProductModal" tabindex="-1" aria-labelledby="addProductModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addProductModalLabel">Adicionar Produto</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="addProductForm" action="home.php?page=produtos&op=new" method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="Nome" class="form-label">Nome</label>
                        <input type="text" class="form-control" name="Nome" id="Nome" required>
                    </div>
                    <div class="mb-3">
                        <label for="Modelo" class="form-label">Capacidade</label>
                        <select class="form-select" name="Modelo" id="Modelo" required>
                            <option value="64GB">64GB</option>
                            <option value="128GB">128GB</option>
                            <option value="256GB">256GB</option>
                            <option value="512GB">512GB</option>
                            <option value="1TB">1TB</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="purchasePrice" class="form-label">Preço de Compra</label>
                        <input type="number" class="form-control" name="PrecoCompra" id="PrecoCompra" step="0.01" required>
                    </div>
                    <div class="mb-3">
                        <label for="PrecoVenda" class="form-label">Preço de Venda</label>
                        <input type="number" class="form-control" name="PrecoVenda" id="PrecoVenda" step="0.01" required>
                    </div>
                    <div class="mb-3">
                        <label for="StockAtual" class="form-label">Stock Atual</label>
                        <input type="number" class="form-control" name="StockAtual" id="StockAtual" required>
                    </div>
                    <div class="mb-3">
                        <label for="Estado" class="form-label">Estado</label>
                        <select class="form-select" name="Estado" id="Estado" required>
                            <option value="Satisfatório">Satisfatório</option>
                            <option value="Bom">Bom</option>
                            <option value="Muito Bom">Muito Bom</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-success">Salvar</button>
                </form>
            </div>
        </div>
    </div>
</div>



<script>
function openAddProductForm() {
    const modal = new bootstrap.Modal(document.getElementById('addProductModal'));
    modal.show();
}

function openEditForm(id) {
    window.location.href = `home.php?page=produtos&op=edit&ProdutoID=${id}`;
}

function deleteProduct(id) {
    if (confirm('Tem certeza que deseja apagar este produto?')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = 'home.php?page=produtos';
        
        const opInput = document.createElement('input');
        opInput.type = 'hidden';
        opInput.name = 'op';
        opInput.value = 'delete';
        form.appendChild(opInput);

        const idInput = document.createElement('input');
        idInput.type = 'hidden';
        idInput.name = 'ProdutoID';
        idInput.value = id;
        form.appendChild(idInput);

        document.body.appendChild(form);
        form.submit();
    }
}
</script>