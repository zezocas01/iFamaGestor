<?php
// Verifica se o cliente foi carregado corretamente
if (!isset($cliente) || empty($cliente)) {
    die("Erro: Cliente não encontrado.");
}
?>

<div class="modal fade" id="editClientModal" tabindex="-1" aria-labelledby="editClientModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editClientModalLabel">Editar Cliente</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="home.php?page=clientes&op=edit" method="POST">
                    <input type="hidden" name="ClienteID" value="<?php echo $cliente['ClienteID']; ?>">
                    
                    <!-- Campos do Formulário -->
                    <div class="mb-3">
                        <label class="form-label">Nome Completo</label>
                        <input type="text" class="form-control" name="Nome" 
                            value="<?php echo htmlspecialchars($cliente['Nome']); ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">NIF</label>
                        <input type="text" class="form-control" name="Nif" 
                            value="<?php echo htmlspecialchars($cliente['Nif']); ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Telefone</label>
                        <input type="tel" class="form-control" name="Telefone" 
                            value="<?php echo htmlspecialchars($cliente['Telefone']); ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" class="form-control" name="Email" 
                            value="<?php echo htmlspecialchars($cliente['Email']); ?>">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Morada</label>
                        <textarea class="form-control" name="Morada" rows="3"><?php echo htmlspecialchars($cliente['Morada']); ?></textarea>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Data de Registo</label>
                        <input type="text" class="form-control" 
                            value="<?php echo date('d/m/Y H:i', strtotime($cliente['DataCriacao'])); ?>" readonly>
                    </div>

                    <button type="submit" class="btn btn-success">Salvar Alterações</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
// Abre o modal automaticamente quando a página carrega
window.onload = function() {
    const modal = new bootstrap.Modal(document.getElementById('editClientModal'));
    modal.show();
};
</script>